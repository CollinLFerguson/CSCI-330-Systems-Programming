/*
Collin L. Ferguson
collin.l.ferguson@und.edu
CSci 330
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef _JUNK_
#define _JUNK_
struct _data
{
    char *name;
    long number;
};

#endif

#include "./hw5-load.h"
#include "./hw5-scan.h"
#include "./hw5-search.h"
#include "./hw5-free.h"

